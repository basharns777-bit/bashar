import React from 'react';
export default function HomePage() {
  return <h1>الصفحة الرئيسية</h1>;
}