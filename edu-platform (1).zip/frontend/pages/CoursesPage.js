import React from 'react';
export default function CoursesPage() {
  return <h1>الكورسات التدريبية</h1>;
}